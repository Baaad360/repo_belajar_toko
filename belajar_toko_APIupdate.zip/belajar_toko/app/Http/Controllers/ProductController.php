<?php

namespace App\Http\Controllers;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
class ProductController extends Controller
{
    public function getproduct()
    {
        $dt_product=Product::get();
        return response()->json($dt_product);
    }
    public function createproduct(Request $req)
    {
        $validator = Validator::make($req->all(),[
            'nama_product'=>'required',
            'harga'=>'required',
        ]);
        if($validator->fails()){
            return response()->json($validator->errors()->tojson());
        }
        $save = Product::create([
            'nama_product'=> $req->get('nama_product'),
            'harga'=> $req->get('harga'),
        ]);
        if ($save) {
            return response()->json(['status'=>true, 'message'=>'sukses menambah product']);
        }else {
            return response()->json(['status'=>false, 'message'=>'gagal menambah product']);
        }
    }
    public function updateproduct(Request $req, $id)
    {
        $validator = Validator::make($req->all(),[
            'nama_product'=>'required',
            'harga'=>'required',
        ]);
        if($validator->fails()){
            return response()->json($validator->errors()->tojson());
        }
        $ubah=Product::where('id_product',$id)->update([
            'nama_product'   => $req->get('nama_product'),
            'harga'=> $req->get('harga'),
        ]);
        if ($ubah) {
            return response()->json(['status'=>true, 'message'=>'sukses update product']);
        }else {
            return response()->json(['status'=>false, 'message'=>'gagal update product']);
        }
    }

}
